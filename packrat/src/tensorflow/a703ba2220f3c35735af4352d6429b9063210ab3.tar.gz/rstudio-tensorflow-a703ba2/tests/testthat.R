library(testthat)
library(tensorflow)

test_check("tensorflow")
